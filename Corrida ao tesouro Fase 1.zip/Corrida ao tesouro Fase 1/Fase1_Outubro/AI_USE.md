# AI_USE.md

Foi usado o OpenAI Codex para ajudar a preparar o rascunho dos documentos da fase 1 e do protótipo Java.
A equipa deve rever, compreender e validar o material antes da entrega.