/* Módulo e finalidade: Modelo de jogador e posição no tabuleiro.
 * Nome/número do aluno e contribuições implementadas: preencher com os dados reais da equipa.
 * Colaborador/revisor e contribuição: preencher após revisão da equipa.
 * Assistência de IA: OpenAI Codex, criação do primeiro rascunho; ver AI_USE.md.
 */
package corridaaotesouro;

/** Representa um peão e a sua posição no percurso. */
public class Jogador {
    private final String nome;
    // Posição 0 representa o castelo, antes da casa numerada 1.
    private int posicao = 0;

    public Jogador(String nome) {
        this.nome = nome;
    }

    public String getNome() { return nome; }
    public int getPosicao() { return posicao; }

    public void avancar(int casas) {
        posicao = Math.min(30, posicao + casas);
    }
}


