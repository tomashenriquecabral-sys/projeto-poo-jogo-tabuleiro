# UML inicial — protótipo de outubro

O diagrama corresponde às classes presentes no protótipo desta pasta. A classe `Main` cria e apresenta a interface Swing; `Jogo` gere os turnos e o movimento; `Jogador` guarda o nome e a posição.

```mermaid
classDiagram
    class Main {
      +main(String[] args)
      -iniciar()
      -mostrar(Jogo jogo)
    }
    class Jogo {
      -List~Jogador~ jogadores
      -int jogadorAtual
      +Jogo(List~String~ nomes)
      +getJogadores() List~Jogador~
      +getJogadorAtual() Jogador
      +moverJogador(int casas) String
    }
    class Jogador {
      -String nome
      -int posicao
      +Jogador(String nome)
      +getNome() String
      +getPosicao() int
      +avancar(int casas) void
    }
    Main ..> Jogo : apresenta e controla
    Jogo "1" *-- "3" Jogador : gere
```

O GitHub apresenta o diagrama Mermaid diretamente nesta página. Este UML é inicial e deve ser revisto pela equipa para refletir as decisões finais.
