# Fase 1 — Marco de outubro

**Projeto:** Corrida ao Tesouro  
**Grupo:** três alunos, com autorização do professor  
**Tecnologia:** Java 17 ou superior, com Swing

Esta pasta tem os materiais do marco de outubro: regras e mapa inicial, esboço da interface gráfica, UML inicial, divisão de tarefas e um protótipo de movimento. Os modos de lançamento do dado e as casas especiais ficam para as fases seguintes.

## Como executar

Com Java 17 ou superior instalado, abra o PowerShell nesta pasta e execute:

```sh
javac -d out src/main/java/corridaaotesouro/*.java
java -cp out corridaaotesouro.Main
```

Introduza os nomes dos três jogadores e escolha um movimento de 1 a 6. Os peões começam no castelo, antes da casa 1. O primeiro movimento leva cada peão até à casa indicada. A janela mostra o castelo, o tabuleiro e de quem é a vez.

## Divisão de tarefas

Preencham os nomes e ajustem a divisão para corresponder ao trabalho que cada pessoa fez.

- Aluno 1: regras, percurso e mapa.
- Aluno 2: protótipo Swing e desenho do tabuleiro.
- Aluno 3: modelo dos jogadores e do movimento, UML e revisão do projeto.

Todos devem rever e compreender o protótipo.
