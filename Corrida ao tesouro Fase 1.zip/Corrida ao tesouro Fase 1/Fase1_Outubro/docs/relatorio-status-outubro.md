# Relatório de situação — marco de outubro

> Antes de enviar, preencham os campos entre parênteses retos com informação verdadeira. Confirmem o endereço do repositório e a versão do código. O relatório deve ter uma página.

**Projeto:** Corrida ao Tesouro  
**Equipa:** [nome e número do aluno 1], [nome e número do aluno 2], [nome e número do aluno 3]  
**Repositório:** [endereço do GitHub]  
**Versão enviada:** [nome da etiqueta ou número do commit]  
**Data:** [data]

## O que já funciona

O protótipo Swing permite introduzir os nomes dos três jogadores, mostra o tabuleiro numerado e deixa fazer um movimento de 1 a 6 casas. Depois do movimento, atualiza a posição e mostra de quem é a vez. **Prova:** [indicar o que foi demonstrado ou acrescentar uma captura de ecrã].

## O que falta fazer

[Indicar o trabalho que ainda falta. Por exemplo: terminar as regras, acrescentar os modos de lançamento do dado, criar as casas especiais e fazer mais verificações. Só indiquem como concluído o que já confirmaram.]

## Trabalho e reflexão de cada aluno

- **[Aluno 1]:** fiz [tarefas, código ou documentos]. Aprendi [o que aprendeu]. Tive dificuldade em [dificuldade] e resolvi-a [decisão tomada].
- **[Aluno 2]:** fiz [tarefas, código ou documentos]. Aprendi [o que aprendeu]. Tive dificuldade em [dificuldade] e resolvi-a [decisão tomada].
- **[Aluno 3]:** fiz [tarefas, código ou documentos]. Aprendi [o que aprendeu]. Tive dificuldade em [dificuldade] e resolvi-a [decisão tomada].

## Próximos passos

[Indicar as próximas tarefas e quem vai tratar de cada uma.]
