# Esboço inicial da interface gráfica

O tabuleiro abaixo foi retirado do projeto original. Na interface, fica ao centro. O castelo é o ponto de partida; a casa 30 é o tesouro. Ao lado do tabuleiro, a janela mostra de quem é a vez, as posições e os controlos do movimento.

![Tabuleiro do projeto Corrida ao Tesouro](imagens/tabuleiro-fundo.png)

## Esboço dos controlos

```text
┌───────────────────────────────────────────────────────────────────────────────┐
│ CORRIDA AO TESOURO                             Três jogadores · 30 casas     │
├───────────────────────────────────────────┬───────────────────────────────────┤
│                                           │ Vez de: [nome]                    │
│                                           │                                   │
│              TABULEIRO                    │ JOGADORES                         │
│          (imagem acima)                   │ [nome] — Castelo/casa             │
│                                           │ [nome] — Castelo/casa             │
│                                           │ [nome] — Castelo/casa             │
│                                           │                                   │
│                                           │ Movimento (1–6): [valor]          │
│                                           │ [Mover]                           │
│                                           │ Mensagem da jogada                │
└───────────────────────────────────────────┴───────────────────────────────────┘
```

Este esboço mostra o tabuleiro do projeto e os controlos previstos para a interface Swing da fase 1.
