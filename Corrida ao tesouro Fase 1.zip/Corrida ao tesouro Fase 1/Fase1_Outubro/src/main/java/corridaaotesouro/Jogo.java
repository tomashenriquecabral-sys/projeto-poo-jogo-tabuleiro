/* Módulo e finalidade: Regras iniciais de ordem de turnos e movimento.
 * Nome/número do aluno e contribuições implementadas: preencher com os dados reais da equipa.
 * Colaborador/revisor e contribuição: preencher após revisão da equipa.
 * Assistência de IA: OpenAI Codex, criação do primeiro rascunho; ver AI_USE.md.
 */
package corridaaotesouro;

import java.util.ArrayList;
import java.util.List;

/** Modelo inicial das posições e do movimento dos jogadores. */
public class Jogo {
    private final List<Jogador> jogadores = new ArrayList<>();
    private int jogadorAtual;

    public Jogo(List<String> nomes) {
        if (nomes == null || nomes.size() != 3) {
            throw new IllegalArgumentException("O protótipo requer três jogadores.");
        }
        for (String nome : nomes) {
            if (nome == null || nome.isBlank()) {
                throw new IllegalArgumentException("Os nomes não podem estar vazios.");
            }
            jogadores.add(new Jogador(nome.trim()));
        }
    }

    public List<Jogador> getJogadores() {
        return List.copyOf(jogadores);
    }

    public Jogador getJogadorAtual() {
        return jogadores.get(jogadorAtual);
    }

    public String moverJogador(int casas) {
        if (casas < 1 || casas > 6) {
            throw new IllegalArgumentException("O movimento deve ser de 1 a 6 casas.");
        }
        Jogador jogador = getJogadorAtual();
        int antes = jogador.getPosicao();
        jogador.avancar(casas);
        jogadorAtual = (jogadorAtual + 1) % jogadores.size();
        String origem = antes == 0 ? "saiu do castelo para a casa "
                : "avançou da casa " + antes + " para a casa ";
        return jogador.getNome() + " " + origem + jogador.getPosicao() + ".";
    }
}


