/* Módulo e finalidade: Protótipo Swing do tabuleiro e movimento inicial.
 * Nome/número do aluno e contribuições implementadas: preencher com os dados reais da equipa.
 * Colaborador/revisor e contribuição: preencher após revisão da equipa.
 * Assistência de IA: OpenAI Codex, criação do primeiro rascunho; ver AI_USE.md.
 */
package corridaaotesouro;

import javax.swing.*;
import java.awt.*;
import java.util.Arrays;

/** Protótipo Swing do movimento e da visualização inicial do tabuleiro. */
public class Main {
    private static final Color[] CORES = {
        new Color(195, 55, 55), new Color(45, 100, 180), new Color(35, 135, 75)
    };

    public static void main(String[] args) {
        SwingUtilities.invokeLater(Main::iniciar);
    }

    private static void iniciar() {
        JTextField[] campos = new JTextField[3];
        JPanel formulario = new JPanel(new GridLayout(3, 2, 6, 6));
        for (int i = 0; i < campos.length; i++) {
            campos[i] = new JTextField("Jogador " + (i + 1));
            formulario.add(new JLabel("Nome do jogador " + (i + 1) + ":"));
            formulario.add(campos[i]);
        }
        if (JOptionPane.showConfirmDialog(null, formulario, "Corrida ao Tesouro",
                JOptionPane.OK_CANCEL_OPTION) != JOptionPane.OK_OPTION) return;
        try {
            Jogo jogo = new Jogo(Arrays.stream(campos).map(JTextField::getText).toList());
            mostrar(jogo);
        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage(), "Dados inválidos", JOptionPane.WARNING_MESSAGE);
        }
    }

    private static void mostrar(Jogo jogo) {
        JFrame janela = new JFrame("Corrida ao Tesouro — protótipo de outubro");
        janela.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        janela.setLayout(new BorderLayout(12, 12));

        JLabel estado = new JLabel();
        JLabel castelo = new JLabel("Castelo — início: ");
        JPanel casas = new JPanel(new GridLayout(5, 6, 5, 5));
        JButton[] celulas = new JButton[30];
        for (int linha = 0; linha < 5; linha++) {
            for (int coluna = 0; coluna < 6; coluna++) {
                int numero = linha % 2 == 0 ? linha * 6 + coluna + 1 : linha * 6 + (6 - coluna);
                JButton casa = new JButton(Integer.toString(numero));
                casa.setEnabled(false);
                casa.setOpaque(true);
                casa.setBackground(Color.WHITE);
                casa.setPreferredSize(new Dimension(86, 72));
                celulas[numero - 1] = casa;
                casas.add(casa);
            }
        }

        JComboBox<String> movimento = new JComboBox<>(new String[]{"1", "2", "3", "4", "5", "6"});
        JButton mover = new JButton("Mover jogador atual");
        JTextArea resumo = new JTextArea(5, 25);
        resumo.setEditable(false);
        JPanel controlos = new JPanel(new FlowLayout(FlowLayout.LEFT));
        controlos.add(castelo);
        controlos.add(estado);
        controlos.add(new JLabel("Movimento de teste:"));
        controlos.add(movimento);
        controlos.add(mover);
        controlos.add(new JScrollPane(resumo));

        Runnable atualizar = () -> {
            castelo.setText("Castelo — início: ");
            for (int i = 0; i < celulas.length; i++) {
                celulas[i].setActionCommand(Integer.toString(i + 1));
                celulas[i].setText(Integer.toString(i + 1));
                celulas[i].setBackground(Color.WHITE);
                celulas[i].setForeground(Color.DARK_GRAY);
            }
            for (int i = 0; i < jogo.getJogadores().size(); i++) {
                Jogador jogador = jogo.getJogadores().get(i);
                if (jogador.getPosicao() == 0) {
                    castelo.setText(castelo.getText() + jogador.getNome() + "  ");
                    continue;
                }
                JButton celula = celulas[jogador.getPosicao() - 1];
                celula.setBackground(CORES[i]);
                celula.setForeground(Color.WHITE);
                celula.setText(jogador.getPosicao() + " · " + jogador.getNome());
            }
            estado.setText("Vez de: " + jogo.getJogadorAtual().getNome());
        };
        atualizar.run();
        mover.addActionListener(e -> {
            try {
                resumo.setText(jogo.moverJogador(Integer.parseInt((String) movimento.getSelectedItem())));
                atualizar.run();
            } catch (IllegalArgumentException ex) {
                JOptionPane.showMessageDialog(janela, ex.getMessage());
            }
        });

        janela.add(new JLabel("Percurso numerado até ao Tesouro (casa 30)", SwingConstants.CENTER), BorderLayout.NORTH);
        janela.add(casas, BorderLayout.CENTER);
        janela.add(controlos, BorderLayout.SOUTH);
        janela.pack();
        janela.setLocationRelativeTo(null);
        janela.setVisible(true);
    }
}


