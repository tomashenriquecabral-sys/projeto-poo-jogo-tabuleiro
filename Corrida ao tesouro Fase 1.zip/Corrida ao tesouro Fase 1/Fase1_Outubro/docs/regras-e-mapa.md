# Regras e mapa inicial — Corrida ao Tesouro

## Regras do protótipo

- Jogam três pessoas, pela ordem dos nomes introduzidos no início.
- Todos começam no castelo, que fica antes da casa 1. No programa, o castelo é a posição 0.
- Em cada turno, o jogador avança entre 1 e 6 casas.
- O percurso vai do castelo até à casa 30.
- Neste protótipo, a posição não passa da casa 30. As regras para ganhar, os lançamentos do dado e as casas especiais serão definidos nas fases seguintes.

## Mapa inicial

`Castelo (início) → 1 → 2 → 3 → … → 29 → 30 (Tesouro)`

| Elemento | Regra ou representação |
|---|---|
| Início | Castelo, antes da casa 1 (posição 0 no programa) |
| Casas normais | Casas 1 a 29 |
| Destino | Casa 30, onde está o tesouro |
| Peões | Três peões, identificados por cor e nome |

No protótipo, as casas aparecem numa grelha numerada. A ordem do percurso é crescente.
